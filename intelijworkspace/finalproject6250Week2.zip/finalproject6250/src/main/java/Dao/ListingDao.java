package Dao;

/**
 * Created by kym-1992 on 4/4/16.
 */
public class ListingDao extends DAO{

}
