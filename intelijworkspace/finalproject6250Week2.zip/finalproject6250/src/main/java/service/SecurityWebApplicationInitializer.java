//package service;
//
//import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;
//
///**
// * Created by kym-1992 on 4/2/16.
// */
//public class SecurityWebApplicationInitializer extends AbstractSecurityWebApplicationInitializer {
//}
