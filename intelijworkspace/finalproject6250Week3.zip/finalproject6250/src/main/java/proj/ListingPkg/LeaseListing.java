package proj.ListingPkg;

/**
 * Created by kym-1992 on 4/4/16.
 */
public class LeaseListing {
}
